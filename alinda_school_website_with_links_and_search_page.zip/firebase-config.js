// Alinda Preparatory School - Kanara
// Firebase web configuration. Access control must be enforced with Firestore Security Rules.
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.4.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDI8Jd318evXwMOQihfz2d0etA4gL66H9M",
  authDomain: "alinda-prep-kanara.firebaseapp.com",
  projectId: "alinda-prep-kanara",
  storageBucket: "alinda-prep-kanara.firebasestorage.app",
  messagingSenderId: "943914685053",
  appId: "1:943914685053:web:c1aa8741754714a801d714",
  measurementId: "G-W8NMNT2M7N"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
